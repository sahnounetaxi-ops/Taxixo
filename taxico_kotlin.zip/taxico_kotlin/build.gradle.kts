// Top-level build file
// Copyright (c) 2026 SahnouneTaxi — Tous droits réservés

plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.kapt) apply false
}
