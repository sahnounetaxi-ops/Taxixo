# 🚕 TAXICO™ — Projet Kotlin Natif
## Copyright (c) 2026 SahnouneTaxi — Tous droits réservés

---

## Ouvrir dans Android Studio

1. **Dézippe** le fichier `taxico_kotlin.zip`
2. Ouvre **Android Studio**
3. **File → Open** → sélectionne le dossier `taxico_kotlin`
4. Attends que Gradle sync se termine (2-3 minutes)
5. Clique ▶ **Run** → sélectionne ton téléphone ou émulateur

---

## Structure du projet

```
taxico_kotlin/
├── app/src/main/
│   ├── java/com/sahnounetaxi/taxico/
│   │   ├── SplashActivity.kt       → Écran de lancement avec logo
│   │   ├── MainActivity.kt         → Navigation principale
│   │   ├── database/
│   │   │   ├── Database.kt         → Room SQLite (BDD locale)
│   │   │   └── Repository.kt       → Accès aux données
│   │   ├── utils/
│   │   │   └── Calculs.kt          → Formules AT/bonus/shift/stats
│   │   ├── viewmodel/
│   │   │   └── TaxicoViewModel.kt  → State management
│   │   └── ui/
│   │       ├── saisie/             → Onglet saisie course
│   │       ├── courses/            → Liste + édition + suppression
│   │       ├── jour/               → Reporting journalier
│   │       ├── mois/               → Reporting mensuel
│   │       ├── annee/              → Reporting annuel
│   │       ├── export/             → Export CSV
│   │       └── profil/             → Profil & paramètres
│   └── res/
│       ├── layout/                 → Tous les layouts XML
│       ├── values/                 → Couleurs, strings, thèmes
│       ├── drawable/               → Backgrounds, icônes
│       ├── navigation/             → Graphe de navigation
│       └── mipmap-*/               → Logo TAXICO (toutes résolutions)
```

---

## Technologies utilisées

| Technologie | Usage |
|---|---|
| **Kotlin** | Langage principal |
| **Room** | BDD SQLite locale sur le téléphone |
| **ViewModel + LiveData** | Architecture MVVM |
| **Navigation Component** | Navigation entre onglets |
| **Material Design 3** | Interface utilisateur |
| **Coroutines** | Opérations asynchrones |

---

## Importer tes données existantes (707 courses)

1. Ouvre ton Google Sheet TAXICO
2. **Fichier → Télécharger → CSV**
3. Dans l'app → onglet **Export** → **Importer CSV**
4. Sélectionne le fichier → toutes tes courses sont importées !

---

## Générer l'APK de release

Dans Android Studio :
1. **Build → Generate Signed Bundle/APK**
2. Choisis **APK**
3. Crée une keystore :
   - Key store path: choisir un dossier
   - Password: ton mot de passe
   - Alias: `sahnounetaxi`
   - First and Last Name: `SahnouneTaxi`
   - Country: `FR`
4. Sélectionne **release**
5. Finish → APK généré dans `app/release/`

---

## Publier sur Google Play

1. Compte développeur : https://play.google.com/console (25$ unique)
2. Uploader l'APK signé
3. Remplir la fiche (description, captures d'écran)
4. Prix suggéré : 4.99€ ou Freemium

---

*TAXICO™ est une marque de SahnouneTaxi*
*sahnounetaxi@gmail.com*
