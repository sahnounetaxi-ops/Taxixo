/**
 * TAXICO™ — Copyright (c) 2026 SahnouneTaxi — Tous droits réservés
 */
package com.sahnounetaxi.taxico.database

import androidx.room.*

// ─── ENTITÉ ─────────────────────────────────────────────────────────────────

@Entity(tableName = "courses")
data class Course(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "date_str")   val dateStr: String,
    @ColumnInfo(name = "heure_str")  val heureStr: String = "",
    @ColumnInfo(name = "montant")    val montant: Double,
    @ColumnInfo(name = "type")       val type: String,
    @ColumnInfo(name = "at")         val at: Double = 0.0,
    @ColumnInfo(name = "eat")        val eat: Double = 0.0,
    @ColumnInfo(name = "bo")         val bo: Double = 0.0,
    @ColumnInfo(name = "tot1")       val tot1: Double,
    @ColumnInfo(name = "total")      val total: Double,
    @ColumnInfo(name = "semaine")    val semaine: Int = 0,
    @ColumnInfo(name = "mois")       val mois: Int = 0,
    @ColumnInfo(name = "created_at") val createdAt: String = ""
)

// ─── DAO ─────────────────────────────────────────────────────────────────────

@Dao
interface CourseDao {

    @Query("SELECT * FROM courses ORDER BY date_str DESC, heure_str DESC, id DESC")
    fun getAllCourses(): kotlinx.coroutines.flow.Flow<List<Course>>

    @Query("SELECT * FROM courses ORDER BY date_str DESC, heure_str DESC, id DESC LIMIT 1")
    suspend fun getLastCourse(): Course?

    @Query("SELECT * FROM courses WHERE date_str = :dateStr ORDER BY heure_str ASC")
    suspend fun getCoursesByDate(dateStr: String): List<Course>

    @Query("SELECT * FROM courses WHERE mois = :mois AND substr(date_str, 7, 4) = :year ORDER BY date_str DESC")
    suspend fun getCoursesByMonth(mois: Int, year: String): List<Course>

    @Query("SELECT * FROM courses WHERE substr(date_str, 7, 4) = :year ORDER BY date_str DESC")
    suspend fun getCoursesByYear(year: String): List<Course>

    @Query("SELECT * FROM courses WHERE date_str >= :from AND date_str <= :to ORDER BY date_str DESC")
    suspend fun getCoursesByRange(from: String, to: String): List<Course>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(course: Course): Long

    @Update
    suspend fun update(course: Course)

    @Delete
    suspend fun delete(course: Course)

    @Query("DELETE FROM courses")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM courses")
    suspend fun getCount(): Int
}

// ─── SETTINGS ────────────────────────────────────────────────────────────────

@Entity(tableName = "settings")
data class Setting(
    @PrimaryKey val key: String,
    val value: String
)

@Dao
interface SettingDao {
    @Query("SELECT value FROM settings WHERE key = :key")
    suspend fun get(key: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun set(setting: Setting)

    @Query("SELECT * FROM settings")
    suspend fun getAll(): List<Setting>
}

// ─── DATABASE ────────────────────────────────────────────────────────────────

@Database(entities = [Course::class, Setting::class], version = 1, exportSchema = false)
abstract class TaxicoDatabase : RoomDatabase() {
    abstract fun courseDao(): CourseDao
    abstract fun settingDao(): SettingDao

    companion object {
        @Volatile private var INSTANCE: TaxicoDatabase? = null

        fun getInstance(context: android.content.Context): TaxicoDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    TaxicoDatabase::class.java,
                    "taxico.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
