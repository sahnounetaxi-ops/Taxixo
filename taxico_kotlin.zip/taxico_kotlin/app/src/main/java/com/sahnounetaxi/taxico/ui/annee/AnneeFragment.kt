/**
 * TAXICO™ — Copyright (c) 2026 SahnouneTaxi — Tous droits réservés
 */
package com.sahnounetaxi.taxico.ui.annee

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.sahnounetaxi.taxico.databinding.FragmentAnneeBinding
import com.sahnounetaxi.taxico.utils.*
import com.sahnounetaxi.taxico.viewmodel.TaxicoViewModel
import com.sahnounetaxi.taxico.viewmodel.TaxicoViewModelFactory
import com.sahnounetaxi.taxico.viewmodel.format0
import com.sahnounetaxi.taxico.viewmodel.format2
import java.util.Calendar

class AnneeFragment : Fragment() {
    private var _binding: FragmentAnneeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: TaxicoViewModel by activityViewModels { TaxicoViewModelFactory(requireActivity().application) }
    private var year = Calendar.getInstance().get(Calendar.YEAR)

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentAnneeBinding.inflate(i, c, false); return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvAnnee.text = year.toString(); loadData()
        binding.btnPrev.setOnClickListener { year--; binding.tvAnnee.text = year.toString(); loadData() }
        binding.btnNext.setOnClickListener { year++; binding.tvAnnee.text = year.toString(); loadData() }
    }

    private fun loadData() {
        viewModel.getCoursesByYear(year) { courses ->
            val s = calcStats(courses)
            viewModel.getCoursesByYear(year - 1) { prev ->
                val caPrev = prev.sumOf { it.total }
                val delta  = if (caPrev > 0) ((s.ca - caPrev) / caPrev * 100) else null

                binding.tvCaTotal.text  = "${s.ca.format0()}€"
                binding.tvCaS.text      = "${s.caS.format0()}€"
                binding.tvNb.text       = s.nb.toString()
                binding.tvPm.text       = "${s.pm.format2()}€"
                binding.tvJours.text    = s.jours.toString()
                binding.tvCaJour.text   = "${s.caJ.format2()}€"
                binding.tvCaSem.text    = "${s.caW.format2()}€"
                binding.tvMeilSem.text  = "${s.mSemVal.format0()}€ S${s.mSemNum}"

                if (delta != null) {
                    val sign = if (delta >= 0) "+" else ""
                    binding.tvDelta.text = "$sign${String.format("%.1f", delta)}% vs ${year-1}"
                    binding.tvDelta.setTextColor(
                        requireContext().getColor(if (delta >= 0) com.sahnounetaxi.taxico.R.color.green else com.sahnounetaxi.taxico.R.color.red)
                    )
                    binding.tvDelta.visibility = View.VISIBLE
                } else binding.tvDelta.visibility = View.GONE
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
