/**
 * TAXICO™ — Copyright (c) 2026 SahnouneTaxi — Tous droits réservés
 */
package com.sahnounetaxi.taxico.viewmodel

import android.app.Application
import androidx.lifecycle.*
import com.sahnounetaxi.taxico.database.*
import com.sahnounetaxi.taxico.utils.*
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.Calendar

class TaxicoViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = TaxicoRepository(TaxicoDatabase.getInstance(application))

    // Toutes les courses en live
    val allCourses: LiveData<List<Course>> = repo.allCourses.asLiveData()

    // Shift courant
    val currentShift: LiveData<ShiftResult> = allCourses.map { courses ->
        val seuil = _settings.value?.get("seuil_pause")?.toIntOrNull() ?: 6
        getCurrentShift(courses, seuil)
    }

    private val _settings = MutableLiveData<Map<String, String>>(emptyMap())
    val settings: LiveData<Map<String, String>> = _settings

    private val _toastMsg = MutableLiveData<String?>()
    val toastMsg: LiveData<String?> = _toastMsg

    init {
        loadSettings()
    }

    fun loadSettings() = viewModelScope.launch {
        _settings.value = repo.getAllSettings()
        repo.getOrCreateUUID()
        _settings.value = repo.getAllSettings()
    }

    fun saveSetting(key: String, value: String) = viewModelScope.launch {
        repo.setSetting(key, value)
        loadSettings()
    }

    fun addCourse(course: Course, onSuccess: (Long) -> Unit = {}) = viewModelScope.launch {
        val id = repo.addCourse(course)
        _toastMsg.value = "✓ ${course.total.format2()}€ (${course.type}) enregistrée !"
        onSuccess(id)
    }

    fun updateCourse(course: Course, onSuccess: () -> Unit = {}) = viewModelScope.launch {
        repo.updateCourse(course)
        _toastMsg.value = "Course mise à jour → ${course.total.format2()}€"
        onSuccess()
    }

    fun deleteCourse(course: Course, onSuccess: () -> Unit = {}) = viewModelScope.launch {
        repo.deleteCourse(course)
        _toastMsg.value = "Course supprimée"
        onSuccess()
    }

    fun getLastCourse(onResult: (Course?) -> Unit) = viewModelScope.launch {
        onResult(repo.getLastCourse())
    }

    fun getCoursesByDate(dateStr: String, onResult: (List<Course>) -> Unit) = viewModelScope.launch {
        onResult(repo.getCoursesByDate(dateStr))
    }

    fun getCoursesByMonth(mois: Int, year: Int, onResult: (List<Course>) -> Unit) = viewModelScope.launch {
        onResult(repo.getCoursesByMonth(mois, year.toString()))
    }

    fun getCoursesByYear(year: Int, onResult: (List<Course>) -> Unit) = viewModelScope.launch {
        onResult(repo.getCoursesByYear(year.toString()))
    }

    fun getCoursesByRange(from: String, to: String, onResult: (List<Course>) -> Unit) = viewModelScope.launch {
        onResult(repo.getCoursesByRange(from, to))
    }

    fun exportCSV(courses: List<Course>, onResult: (String) -> Unit) = viewModelScope.launch {
        val uuid = repo.getSetting("uuid")
        val nom  = repo.getSetting("nom")
        onResult(coursesToCSV(courses, uuid, nom))
    }

    fun importCourses(courses: List<Course>, onDone: (Int) -> Unit) = viewModelScope.launch {
        var count = 0
        courses.forEach { repo.addCourse(it.copy(id = 0)); count++ }
        _toastMsg.value = "$count courses importées !"
        onDone(count)
    }

    fun clearToast() { _toastMsg.value = null }

    fun getSettingValue(key: String, default: String = "") =
        _settings.value?.get(key) ?: default
}

fun Double.format2() = String.format("%.2f", this)
fun Double.format0() = String.format("%.0f", this)

class TaxicoViewModelFactory(private val app: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return TaxicoViewModel(app) as T
    }
}
