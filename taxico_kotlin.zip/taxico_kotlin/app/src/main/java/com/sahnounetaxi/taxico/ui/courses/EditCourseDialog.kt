/**
 * TAXICO™ — Copyright (c) 2026 SahnouneTaxi — Tous droits réservés
 */
package com.sahnounetaxi.taxico.ui.courses

import android.app.Dialog
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import com.sahnounetaxi.taxico.database.Course
import com.sahnounetaxi.taxico.databinding.DialogEditCourseBinding
import com.sahnounetaxi.taxico.utils.*
import com.sahnounetaxi.taxico.viewmodel.TaxicoViewModel
import com.sahnounetaxi.taxico.viewmodel.format2

class EditCourseDialog(
    private val course: Course,
    private val viewModel: TaxicoViewModel,
    private val onDone: () -> Unit
) : DialogFragment() {

    private var _binding: DialogEditCourseBinding? = null
    private val binding get() = _binding!!
    private var selectedType = course.type

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = DialogEditCourseBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Pré-remplir avec les valeurs d'origine
        binding.etDate.setText(course.dateStr)
        binding.etHeure.setText(course.heureStr)
        binding.etMontant.setText(course.montant.toString())
        binding.etAt.setText(if (course.at > 0) course.at.toString() else "")
        binding.etBo.setText(if (course.bo > 0) course.bo.toString() else "")
        binding.tvSub.text = "Ligne ${course.id} · ${course.dateStr}${if (course.heureStr.isNotEmpty()) " à ${course.heureStr}" else ""}"

        setupTypeButtons()
        updateCalc()

        listOf(binding.etMontant, binding.etAt, binding.etBo).forEach { et ->
            et.addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) = updateCalc()
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, a: Int) {}
            })
        }

        // Enregistrer
        binding.btnSave.setOnClickListener {
            val montant = binding.etMontant.text.toString().toDoubleOrNull()
            if (montant == null || montant <= 0) {
                Toast.makeText(context, "Montant invalide", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val at   = binding.etAt.text.toString().toDoubleOrNull() ?: 0.0
            val bo   = binding.etBo.text.toString().toDoubleOrNull() ?: 0.0
            val eat  = calcEAT(at)
            val tot1 = calcTot1(montant, selectedType)
            val total = calcTotal(tot1, eat, bo)
            val dateStr = binding.etDate.text.toString()
            val date = fromFr(dateStr) ?: today()

            val updated = course.copy(
                dateStr  = dateStr,
                heureStr = binding.etHeure.text.toString(),
                montant  = montant, type = selectedType,
                at = at, eat = eat, bo = bo,
                tot1 = tot1, total = total,
                semaine = getISOWeek(date), mois = getMonth(dateStr)
            )
            viewModel.updateCourse(updated) { dismiss(); onDone() }
        }

        // Supprimer
        binding.btnDelete.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Supprimer")
                .setMessage("Supprimer la course du ${course.dateStr} — ${course.total.format2()}€ (${course.type}) ?\n\nCette action est irréversible.")
                .setPositiveButton("Supprimer") { _, _ ->
                    viewModel.deleteCourse(course) { dismiss(); onDone() }
                }
                .setNegativeButton("Annuler", null)
                .show()
        }

        binding.btnCancel.setOnClickListener { dismiss() }
    }

    private fun setupTypeButtons() {
        val buttons = listOf(
            binding.btnEsp, binding.btnCb, binding.btnCbvip, binding.btnChg7,
            binding.btnClub, binding.btnRlv, binding.btnRlvPlus
        )
        buttons.forEachIndexed { i, btn ->
            btn.text = TYPES[i]
            btn.isSelected = TYPES[i] == selectedType
            btn.setOnClickListener {
                selectedType = TYPES[i]
                buttons.forEach { b -> b.isSelected = b.text == selectedType }
                updateCalc()
            }
        }
    }

    private fun updateCalc() {
        val m   = binding.etMontant.text.toString().toDoubleOrNull() ?: 0.0
        val at  = binding.etAt.text.toString().toDoubleOrNull() ?: 0.0
        val bo  = binding.etBo.text.toString().toDoubleOrNull() ?: 0.0
        val eat   = calcEAT(at)
        val tot1  = calcTot1(m, selectedType)
        val total = calcTotal(tot1, eat, bo)
        var txt = "${tot1.format2()}€"
        if (eat > 0) txt += " + AT: ${eat.format2()}€"
        if (bo > 0)  txt += " + Bonus: ${bo.format2()}€"
        txt += "\nTotal → ${total.format2()}€"
        binding.tvCalc.text = txt
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
