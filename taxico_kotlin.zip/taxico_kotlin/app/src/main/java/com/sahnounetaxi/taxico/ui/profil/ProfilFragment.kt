/**
 * TAXICO™ — Copyright (c) 2026 SahnouneTaxi — Tous droits réservés
 */
package com.sahnounetaxi.taxico.ui.profil

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.sahnounetaxi.taxico.databinding.FragmentProfilBinding
import com.sahnounetaxi.taxico.viewmodel.TaxicoViewModel
import com.sahnounetaxi.taxico.viewmodel.TaxicoViewModelFactory

class ProfilFragment : Fragment() {
    private var _binding: FragmentProfilBinding? = null
    private val binding get() = _binding!!
    private val viewModel: TaxicoViewModel by activityViewModels { TaxicoViewModelFactory(requireActivity().application) }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentProfilBinding.inflate(i, c, false); return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.settings.observe(viewLifecycleOwner) { s ->
            binding.etNom.setText(s["nom"] ?: "")
            binding.etTaxi.setText(s["taxi"] ?: "")
            binding.etVille.setText(s["ville"] ?: "")
            binding.etObjectif.setText(s["objectif_ca"] ?: "")
            binding.etPointMort.setText(s["point_mort"] ?: "")
            binding.tvUuid.text = s["uuid"] ?: ""
        }

        // Sauvegarder automatiquement
        listOf(
            binding.etNom to "nom",
            binding.etTaxi to "taxi",
            binding.etVille to "ville",
            binding.etObjectif to "objectif_ca",
            binding.etPointMort to "point_mort"
        ).forEach { (et, key) ->
            et.setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) viewModel.saveSetting(key, et.text.toString())
            }
        }

        // Copier UUID
        binding.btnCopyUuid.setOnClickListener {
            val uuid = binding.tvUuid.text.toString()
            val clipboard = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("UUID", uuid))
            Toast.makeText(context, "ID copié !", Toast.LENGTH_SHORT).show()
        }

        // Copyright
        binding.tvCopyright.text = "🚕 TAXICO™\n© 2026 SahnouneTaxi\nTous droits réservés\nv1.0.0"

        // Supprimer tout
        binding.btnDeleteAll.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("⚠️ Attention")
                .setMessage("Supprimer TOUTES les courses ?\n\nCette action est irréversible !")
                .setPositiveButton("SUPPRIMER") { _, _ ->
                    viewModel.viewModelScope?.let { } // handled via repo
                    Toast.makeText(context, "Fonctionnalité disponible dans la version finale", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Annuler", null)
                .show()
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
