/**
 * TAXICO™ — Copyright (c) 2026 SahnouneTaxi — Tous droits réservés
 */
package com.sahnounetaxi.taxico.ui.jour

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.sahnounetaxi.taxico.databinding.FragmentJourBinding
import com.sahnounetaxi.taxico.utils.*
import com.sahnounetaxi.taxico.viewmodel.TaxicoViewModel
import com.sahnounetaxi.taxico.viewmodel.TaxicoViewModelFactory
import com.sahnounetaxi.taxico.viewmodel.format2
import java.util.Calendar

class JourFragment : Fragment() {
    private var _binding: FragmentJourBinding? = null
    private val binding get() = _binding!!
    private val viewModel: TaxicoViewModel by activityViewModels { TaxicoViewModelFactory(requireActivity().application) }
    private var currentDate = todayStr()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentJourBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvDate.text = currentDate
        loadData()
        binding.btnPrev.setOnClickListener { shiftDate(-1) }
        binding.btnNext.setOnClickListener { shiftDate(1) }
    }

    private fun shiftDate(delta: Int) {
        val d = fromFr(currentDate) ?: return
        val cal = Calendar.getInstance().apply { time = d; add(Calendar.DAY_OF_YEAR, delta) }
        currentDate = toFr(cal.time)
        binding.tvDate.text = currentDate
        loadData()
    }

    private fun loadData() {
        viewModel.getCoursesByDate(currentDate) { courses ->
            val stats = calcStats(courses)
            val obj = viewModel.getSettingValue("objectif_ca").toDoubleOrNull() ?: 0.0
            val pm  = viewModel.getSettingValue("point_mort").toDoubleOrNull() ?: 0.0

            binding.tvCaTotal.text  = "${stats.ca.format2()}€"
            binding.tvCaS.text      = "${stats.caS.format2()}€"
            binding.tvNb.text       = stats.nb.toString()
            binding.tvPm.text       = "${stats.pm.format2()}€"

            // Objectif
            if (obj > 0) {
                val pct = (stats.ca / obj * 100).coerceAtMost(100.0).toInt()
                binding.progressObj.progress = pct
                binding.tvObjPct.text = "$pct%"
                binding.layoutObj.visibility = View.VISIBLE
            } else {
                binding.layoutObj.visibility = View.GONE
            }

            // Point mort
            if (pm > 0) {
                if (stats.ca >= pm) {
                    binding.tvPmStatus.text = "✅ Point mort atteint"
                    binding.tvPmStatus.setTextColor(requireContext().getColor(com.sahnounetaxi.taxico.R.color.green))
                } else {
                    binding.tvPmStatus.text = "⏳ Reste ${(pm - stats.ca).format2()}€ pour point mort"
                    binding.tvPmStatus.setTextColor(requireContext().getColor(com.sahnounetaxi.taxico.R.color.red))
                }
                binding.tvPmStatus.visibility = View.VISIBLE
            } else {
                binding.tvPmStatus.visibility = View.GONE
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
