/**
 * TAXICO™ — Copyright (c) 2026 SahnouneTaxi — Tous droits réservés
 */
package com.sahnounetaxi.taxico.ui.courses

import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sahnounetaxi.taxico.database.Course
import com.sahnounetaxi.taxico.databinding.FragmentCoursesBinding
import com.sahnounetaxi.taxico.databinding.ItemCourseBinding
import com.sahnounetaxi.taxico.utils.*
import com.sahnounetaxi.taxico.viewmodel.TaxicoViewModel
import com.sahnounetaxi.taxico.viewmodel.TaxicoViewModelFactory
import com.sahnounetaxi.taxico.viewmodel.format2

class CoursesFragment : Fragment() {

    private var _binding: FragmentCoursesBinding? = null
    private val binding get() = _binding!!
    private val viewModel: TaxicoViewModel by activityViewModels { TaxicoViewModelFactory(requireActivity().application) }
    private lateinit var adapter: CoursesAdapter
    private var allData: List<Course> = emptyList()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentCoursesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = CoursesAdapter { course -> showEditDialog(course) }
        binding.recyclerView.layoutManager = LinearLayoutManager(context)
        binding.recyclerView.adapter = adapter

        viewModel.allCourses.observe(viewLifecycleOwner) { courses ->
            allData = courses
            applyFilter()
        }

        binding.btnClearFilter.setOnClickListener {
            binding.etFilterDate.setText("")
            binding.spinnerType.setSelection(0)
            applyFilter()
        }
    }

    private fun applyFilter() {
        val dateFilter = binding.etFilterDate.text.toString().trim()
        var filtered = allData
        if (dateFilter.isNotEmpty()) filtered = filtered.filter { it.dateStr.contains(dateFilter) }
        adapter.submitList(filtered)
        val total = filtered.sumOf { it.total }
        binding.tvCount.text = "${filtered.size} courses · ${total.format2()}€"
    }

    private fun showEditDialog(course: Course) {
        val dialog = EditCourseDialog(course, viewModel) { applyFilter() }
        dialog.show(childFragmentManager, "edit_course")
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

// ─── ADAPTER ─────────────────────────────────────────────────────────────────

class CoursesAdapter(private val onClick: (Course) -> Unit) :
    RecyclerView.Adapter<CoursesAdapter.VH>() {

    private var items: List<Course> = emptyList()

    fun submitList(list: List<Course>) { items = list; notifyDataSetChanged() }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemCourseBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(items[position])

    inner class VH(private val b: ItemCourseBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(c: Course) {
            b.tvDate.text  = c.dateStr
            b.tvHeure.text = if (c.heureStr.isNotEmpty()) "🕐 ${c.heureStr}" else ""
            b.tvTotal.text = "${c.total.format2()} €"
            b.tvType.text  = c.type
            b.tvBase.text  = if (c.total != c.montant) "${c.montant.format2()}€ base" else ""
            val extras = mutableListOf<String>()
            if (c.at > 0) extras.add("⏱ ${c.at.toInt()}min")
            if (c.bo > 0) extras.add("🎁 +${c.bo.format2()}€")
            b.tvExtras.text = extras.joinToString(" · ")
            b.root.setOnClickListener { onClick(c) }
        }
    }
}
