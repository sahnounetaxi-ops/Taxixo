/**
 * TAXICO™ — Copyright (c) 2026 SahnouneTaxi — Tous droits réservés
 */
package com.sahnounetaxi.taxico.ui.mois

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.sahnounetaxi.taxico.databinding.FragmentMoisBinding
import com.sahnounetaxi.taxico.utils.*
import com.sahnounetaxi.taxico.viewmodel.TaxicoViewModel
import com.sahnounetaxi.taxico.viewmodel.TaxicoViewModelFactory
import com.sahnounetaxi.taxico.viewmodel.format2
import java.util.Calendar

class MoisFragment : Fragment() {
    private var _binding: FragmentMoisBinding? = null
    private val binding get() = _binding!!
    private val viewModel: TaxicoViewModel by activityViewModels { TaxicoViewModelFactory(requireActivity().application) }
    private var month = Calendar.getInstance().get(Calendar.MONTH) + 1
    private var year  = Calendar.getInstance().get(Calendar.YEAR)

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentMoisBinding.inflate(i, c, false); return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        updateHeader(); loadData()
        binding.btnPrev.setOnClickListener { shift(-1) }
        binding.btnNext.setOnClickListener { shift(1) }
    }

    private fun shift(d: Int) {
        month += d
        if (month > 12) { month = 1; year++ }
        if (month < 1)  { month = 12; year-- }
        updateHeader(); loadData()
    }

    private fun updateHeader() {
        binding.tvPeriode.text = "${MOIS[month-1]} $year"
    }

    private fun loadData() {
        viewModel.getCoursesByMonth(month, year) { courses ->
            val s = calcStats(courses)
            // Mois précédent pour comparaison
            val prevM = if (month == 1) 12 else month - 1
            val prevY = if (month == 1) year - 1 else year
            viewModel.getCoursesByMonth(prevM, prevY) { prev ->
                val caPrev = prev.sumOf { it.total }
                val delta  = if (caPrev > 0) ((s.ca - caPrev) / caPrev * 100) else null

                binding.tvCaTotal.text = "${s.ca.format2()}€"
                binding.tvCaS.text     = "${s.caS.format2()}€"
                binding.tvNb.text      = s.nb.toString()
                binding.tvPm.text      = "${s.pm.format2()}€"
                binding.tvJours.text   = "${s.jours}j"
                binding.tvCaJour.text  = "${s.caJ.format2()}€"
                binding.tvCaSem.text   = "${s.caW.format2()}€"
                binding.tvMeilSem.text = "${s.mSemVal.format2()}€ S${s.mSemNum}"

                if (delta != null) {
                    val sign = if (delta >= 0) "+" else ""
                    binding.tvDelta.text = "$sign${String.format("%.1f", delta)}% vs ${MOIS[prevM-1].take(4)}"
                    binding.tvDelta.setTextColor(
                        requireContext().getColor(
                            if (delta >= 0) com.sahnounetaxi.taxico.R.color.green
                            else com.sahnounetaxi.taxico.R.color.red
                        )
                    )
                    binding.tvDelta.visibility = View.VISIBLE
                } else {
                    binding.tvDelta.visibility = View.GONE
                }
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
