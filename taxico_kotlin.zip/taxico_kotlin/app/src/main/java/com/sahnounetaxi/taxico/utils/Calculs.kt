/**
 * TAXICO™ — Copyright (c) 2026 SahnouneTaxi — Tous droits réservés
 */
package com.sahnounetaxi.taxico.utils

import java.text.SimpleDateFormat
import java.util.*

// ─── TYPES ───────────────────────────────────────────────────────────────────

val TYPES = listOf("ESP", "CB", "CBVIP", "CHG7", "CLUB", "RLV", "RLV+")

val MOIS = listOf(
    "Janvier","Février","Mars","Avril","Mai","Juin",
    "Juillet","Août","Septembre","Octobre","Novembre","Décembre"
)

// ─── CALCULS ─────────────────────────────────────────────────────────────────

fun r2(v: Double) = Math.round(v * 100.0) / 100.0

fun calcEAT(at: Double): Double {
    return if (at >= 11) r2(at * 0.30) else 0.0
}

fun calcTot1(montant: Double, type: String): Double {
    return when (type) {
        "CLUB" -> r2(montant * 1.2)
        "RLV+" -> r2(montant * 1.15)
        else   -> montant
    }
}

fun calcTotal(tot1: Double, eat: Double, bo: Double): Double {
    return r2(tot1 + eat + bo)
}

// ─── DATES ───────────────────────────────────────────────────────────────────

private val FMT_FR  = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE)
private val FMT_ISO = SimpleDateFormat("yyyy-MM-dd", Locale.FRANCE)

fun toFr(date: Date): String = FMT_FR.format(date)
fun toIso(date: Date): String = FMT_ISO.format(date)
fun fromFr(str: String): Date? = try { FMT_FR.parse(str) } catch (e: Exception) { null }
fun fromIso(str: String): Date? = try { FMT_ISO.parse(str) } catch (e: Exception) { null }

fun today(): Date = Calendar.getInstance().time
fun todayStr(): String = toFr(today())
fun todayIso(): String = toIso(today())

fun getYear(dateStr: String): Int {
    val d = fromFr(dateStr) ?: return 0
    return Calendar.getInstance().apply { time = d }.get(Calendar.YEAR)
}

fun getMonth(dateStr: String): Int {
    val d = fromFr(dateStr) ?: return 0
    return Calendar.getInstance().apply { time = d }.get(Calendar.MONTH) + 1
}

fun getISOWeek(date: Date): Int {
    return Calendar.getInstance(Locale.FRANCE).apply {
        minimalDaysInFirstWeek = 4
        firstDayOfWeek = Calendar.MONDAY
        time = date
    }.get(Calendar.WEEK_OF_YEAR)
}

fun dateToTs(dateStr: String, heureStr: String): Long {
    val d = fromFr(dateStr) ?: return 0L
    val cal = Calendar.getInstance().apply { time = d }
    if (heureStr.contains(":")) {
        val parts = heureStr.split(":")
        cal.set(Calendar.HOUR_OF_DAY, parts[0].toIntOrNull() ?: 0)
        cal.set(Calendar.MINUTE, parts[1].toIntOrNull() ?: 0)
    }
    return cal.timeInMillis
}

fun formatDate(dateStr: String): String = dateStr  // "dd/MM/yyyy" déjà formaté

// ─── SHIFT ───────────────────────────────────────────────────────────────────

data class ShiftResult(val courses: List<com.sahnounetaxi.taxico.database.Course>, val ca: Double)

fun getCurrentShift(
    allCourses: List<com.sahnounetaxi.taxico.database.Course>,
    seuilHeures: Int = 6
): ShiftResult {
    val seuilMs = seuilHeures * 3600_000L

    val avecHeure = allCourses.filter { it.heureStr.contains(":") }

    if (avecHeure.isEmpty()) {
        val todayStr = todayStr()
        val cs = allCourses.filter { it.dateStr == todayStr }
        return ShiftResult(cs, cs.sumOf { it.total })
    }

    val sorted = avecHeure.sortedByDescending { dateToTs(it.dateStr, it.heureStr) }
    val shift = mutableListOf(sorted[0])
    val tsRef = dateToTs(sorted[0].dateStr, sorted[0].heureStr)
    val limite = tsRef - 36 * 3600_000L

    for (i in 1 until sorted.size) {
        val tsCurr = dateToTs(sorted[i].dateStr, sorted[i].heureStr)
        if (tsCurr < limite) break
        val tsPrev = dateToTs(sorted[i-1].dateStr, sorted[i-1].heureStr)
        if (tsPrev - tsCurr > seuilMs) break
        shift.add(sorted[i])
    }

    return ShiftResult(shift, shift.sumOf { it.total })
}

// ─── STATS ───────────────────────────────────────────────────────────────────

data class Stats(
    val ca: Double, val caS: Double, val nb: Int, val pm: Double,
    val jours: Int, val caJ: Double, val caW: Double,
    val mSemVal: Double, val mSemNum: Int,
    val byType: Map<String, Double>
)

fun calcStats(courses: List<com.sahnounetaxi.taxico.database.Course>): Stats {
    val ca  = courses.sumOf { it.total }
    val caS = courses.filter { it.type != "ESP" }.sumOf { it.total }
    val nb  = courses.size
    val pm  = if (nb > 0) ca / nb else 0.0
    val jours = courses.map { it.dateStr }.toSet().size
    val caJ = if (jours > 0) ca / jours else 0.0

    val semMap = mutableMapOf<Int, Double>()
    courses.forEach { semMap[it.semaine] = (semMap[it.semaine] ?: 0.0) + it.total }
    val caW = if (semMap.isNotEmpty()) ca / semMap.size else 0.0
    val mSemVal = semMap.values.maxOrNull() ?: 0.0
    val mSemNum = semMap.entries.maxByOrNull { it.value }?.key ?: 0

    val byType = TYPES.associateWith { t -> courses.filter { it.type == t }.sumOf { it.total } }

    return Stats(ca, caS, nb, pm, jours, caJ, caW, mSemVal, mSemNum, byType)
}

// ─── EXPORT CSV ──────────────────────────────────────────────────────────────

fun coursesToCSV(
    courses: List<com.sahnounetaxi.taxico.database.Course>,
    userId: String = "",
    nom: String = ""
): String {
    val sb = StringBuilder()
    sb.appendLine("user_id,nom,date,heure,montant,type,at,eat,bonus,tot1,total,semaine,mois")
    courses.forEach { c ->
        sb.appendLine("$userId,$nom,${c.dateStr},${c.heureStr},${c.montant},${c.type},${c.at},${c.eat},${c.bo},${c.tot1},${c.total},${c.semaine},${c.mois}")
    }
    return sb.toString()
}

// ─── UUID ────────────────────────────────────────────────────────────────────

fun generateUUID(): String = UUID.randomUUID().toString()
