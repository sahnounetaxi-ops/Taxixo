/**
 * TAXICO™ — Copyright (c) 2026 SahnouneTaxi — Tous droits réservés
 */
package com.sahnounetaxi.taxico.ui.saisie

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.sahnounetaxi.taxico.MainActivity
import com.sahnounetaxi.taxico.database.Course
import com.sahnounetaxi.taxico.databinding.FragmentSaisieBinding
import com.sahnounetaxi.taxico.utils.*
import com.sahnounetaxi.taxico.viewmodel.TaxicoViewModel
import com.sahnounetaxi.taxico.viewmodel.TaxicoViewModelFactory
import com.sahnounetaxi.taxico.viewmodel.format2
import java.util.Calendar

class SaisieFragment : Fragment() {

    private var _binding: FragmentSaisieBinding? = null
    private val binding get() = _binding!!
    private val viewModel: TaxicoViewModel by activityViewModels { TaxicoViewModelFactory(requireActivity().application) }

    private var selectedType = "CB"

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSaisieBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupDateHeure()
        setupTypeButtons()
        setupCalcPreview()
        setupButtons()
        observeShift()
        checkMidnightAlert()
    }

    private fun setupDateHeure() {
        val cal = Calendar.getInstance()
        binding.etDate.setText(todayStr())
        binding.etHeure.setText(String.format("%02d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE)))
    }

    private fun setupTypeButtons() {
        val buttons = listOf(
            binding.btnEsp, binding.btnCb, binding.btnCbvip, binding.btnChg7,
            binding.btnClub, binding.btnRlv, binding.btnRlvPlus
        )
        val types = TYPES

        buttons.forEachIndexed { i, btn ->
            btn.text = types[i]
            btn.setOnClickListener {
                selectedType = types[i]
                buttons.forEach { b -> b.isSelected = b.text == selectedType }
                updateCalcPreview()
            }
        }
        binding.btnCb.isSelected = true
    }

    private fun setupCalcPreview() {
        listOf(binding.etMontant, binding.etAt, binding.etBo).forEach { et ->
            et.addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) = updateCalcPreview()
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, a: Int) {}
            })
        }
    }

    private fun updateCalcPreview() {
        val m   = binding.etMontant.text.toString().toDoubleOrNull() ?: 0.0
        val at  = binding.etAt.text.toString().toDoubleOrNull() ?: 0.0
        val bo  = binding.etBo.text.toString().toDoubleOrNull() ?: 0.0
        if (m == 0.0 && at == 0.0 && bo == 0.0) {
            binding.tvCalcPreview.visibility = View.GONE
            return
        }
        val eat   = calcEAT(at)
        val tot1  = calcTot1(m, selectedType)
        val total = calcTotal(tot1, eat, bo)
        var txt = "${tot1.format2()}€"
        if (eat > 0) txt += " + AT: ${eat.format2()}€"
        if (bo > 0)  txt += " + Bonus: ${bo.format2()}€"
        txt += " → Total: ${total.format2()}€"
        binding.tvCalcPreview.text = txt
        binding.tvCalcPreview.visibility = View.VISIBLE
    }

    private fun setupButtons() {
        // Attente & Bonus toggle
        binding.btnAdvToggle.setOnClickListener {
            val visible = binding.layoutAdv.visibility == View.VISIBLE
            binding.layoutAdv.visibility = if (visible) View.GONE else View.VISIBLE
            binding.btnAdvToggle.text = if (visible) "▶ Attente & Bonus" else "▼ Attente & Bonus"
        }

        // Enregistrer
        binding.btnSave.setOnClickListener { saveCourse() }

        // Dupliquer
        binding.btnDuplique.setOnClickListener {
            viewModel.getLastCourse { last ->
                if (last == null) {
                    Toast.makeText(context, "Aucune course précédente", Toast.LENGTH_SHORT).show()
                } else {
                    binding.etMontant.setText(last.montant.toString())
                    selectType(last.type)
                    if (last.at > 0) {
                        binding.layoutAdv.visibility = View.VISIBLE
                        binding.etAt.setText(last.at.toString())
                    }
                    if (last.bo > 0) {
                        binding.layoutAdv.visibility = View.VISIBLE
                        binding.etBo.setText(last.bo.toString())
                    }
                    updateCalcPreview()
                }
            }
        }
    }

    private fun selectType(type: String) {
        selectedType = type
        listOf(binding.btnEsp, binding.btnCb, binding.btnCbvip, binding.btnChg7,
               binding.btnClub, binding.btnRlv, binding.btnRlvPlus).forEach { b ->
            b.isSelected = b.text == type
        }
    }

    private fun saveCourse() {
        val montantStr = binding.etMontant.text.toString()
        val montant = montantStr.toDoubleOrNull()
        if (montant == null || montant <= 0) {
            Toast.makeText(context, "Montant invalide", Toast.LENGTH_SHORT).show()
            return
        }
        val dateStr  = binding.etDate.text.toString()
        val heureStr = binding.etHeure.text.toString()
        val at  = binding.etAt.text.toString().toDoubleOrNull() ?: 0.0
        val bo  = binding.etBo.text.toString().toDoubleOrNull() ?: 0.0
        val eat = calcEAT(at)
        val tot1  = calcTot1(montant, selectedType)
        val total = calcTotal(tot1, eat, bo)
        val date  = fromFr(dateStr) ?: today()

        val course = Course(
            dateStr  = dateStr,
            heureStr = heureStr,
            montant  = montant,
            type     = selectedType,
            at = at, eat = eat, bo = bo,
            tot1 = tot1, total = total,
            semaine = getISOWeek(date),
            mois    = getMonth(dateStr)
        )

        binding.btnSave.isEnabled = false
        viewModel.addCourse(course) {
            binding.etMontant.setText("")
            binding.etAt.setText("")
            binding.etBo.setText("")
            binding.tvCalcPreview.visibility = View.GONE
            binding.btnSave.isEnabled = true
            binding.etMontant.requestFocus()
        }
    }

    private fun observeShift() {
        viewModel.currentShift.observe(viewLifecycleOwner) { shift ->
            val obj = viewModel.getSettingValue("objectif_ca").toDoubleOrNull() ?: 0.0
            val pm  = viewModel.getSettingValue("point_mort").toDoubleOrNull() ?: 0.0
            binding.tvShiftCa.text = "${shift.ca.format2()}€"
            if (obj > 0) {
                val pct = (shift.ca / obj * 100).coerceAtMost(100.0).toInt()
                binding.progressShift.progress = pct
                binding.tvShiftPct.text = "$pct%"
                binding.tvShiftPct.visibility = View.VISIBLE
            } else {
                binding.progressShift.progress = 0
                binding.tvShiftPct.visibility = View.GONE
            }
            if (pm > 0) {
                if (shift.ca >= pm) {
                    binding.tvShiftLabel.text = "Shift ✅"
                } else {
                    binding.tvShiftLabel.text = "Shift ${(pm - shift.ca).format2()}€→PM"
                }
            } else {
                binding.tvShiftLabel.text = "Shift"
            }
        }
    }

    private fun checkMidnightAlert() {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val seuil = viewModel.getSettingValue("fenetre_minuit", "2").toIntOrNull() ?: 2
        if (h < seuil) {
            binding.layoutMidnight.visibility = View.VISIBLE
            binding.tvMidnightHeure.text = "Il est ${String.format("%02d", h)}h — cette course date de :"
            val hier = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
            binding.btnMidnightHier.text = "← ${toFr(hier.time)} (nuit)"
            binding.btnMidnightAuj.text  = "${todayStr()} →"
            binding.btnMidnightHier.setOnClickListener {
                binding.etDate.setText(toFr(hier.time))
                binding.btnMidnightHier.isSelected = true
                binding.btnMidnightAuj.isSelected = false
            }
            binding.btnMidnightAuj.setOnClickListener {
                binding.etDate.setText(todayStr())
                binding.btnMidnightAuj.isSelected = true
                binding.btnMidnightHier.isSelected = false
            }
            // Présélectionner "hier" par défaut (taxi de nuit)
            binding.btnMidnightHier.performClick()
        } else {
            binding.layoutMidnight.visibility = View.GONE
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
