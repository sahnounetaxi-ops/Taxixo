/**
 * TAXICO™ — Copyright (c) 2026 SahnouneTaxi — Tous droits réservés
 */
package com.sahnounetaxi.taxico.database

import com.sahnounetaxi.taxico.utils.generateUUID
import kotlinx.coroutines.flow.Flow

class TaxicoRepository(private val db: TaxicoDatabase) {

    val allCourses: Flow<List<Course>> = db.courseDao().getAllCourses()

    suspend fun addCourse(course: Course): Long = db.courseDao().insert(course)
    suspend fun updateCourse(course: Course) = db.courseDao().update(course)
    suspend fun deleteCourse(course: Course) = db.courseDao().delete(course)
    suspend fun getLastCourse(): Course? = db.courseDao().getLastCourse()
    suspend fun getCoursesByDate(dateStr: String) = db.courseDao().getCoursesByDate(dateStr)
    suspend fun getCoursesByMonth(mois: Int, year: String) = db.courseDao().getCoursesByMonth(mois, year)
    suspend fun getCoursesByYear(year: String) = db.courseDao().getCoursesByYear(year)
    suspend fun getCoursesByRange(from: String, to: String) = db.courseDao().getCoursesByRange(from, to)
    suspend fun getCount() = db.courseDao().getCount()
    suspend fun deleteAll() = db.courseDao().deleteAll()

    // Settings
    suspend fun getSetting(key: String, default: String = ""): String =
        db.settingDao().get(key) ?: default

    suspend fun setSetting(key: String, value: String) =
        db.settingDao().set(Setting(key, value))

    suspend fun getAllSettings(): Map<String, String> =
        db.settingDao().getAll().associate { it.key to it.value }

    suspend fun getOrCreateUUID(): String {
        val existing = getSetting("uuid")
        if (existing.isNotEmpty()) return existing
        val uuid = generateUUID()
        setSetting("uuid", uuid)
        return uuid
    }
}
