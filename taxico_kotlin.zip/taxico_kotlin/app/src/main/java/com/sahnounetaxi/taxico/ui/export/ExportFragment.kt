/**
 * TAXICO™ — Copyright (c) 2026 SahnouneTaxi — Tous droits réservés
 */
package com.sahnounetaxi.taxico.ui.export

import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.sahnounetaxi.taxico.databinding.FragmentExportBinding
import com.sahnounetaxi.taxico.viewmodel.TaxicoViewModel
import com.sahnounetaxi.taxico.viewmodel.TaxicoViewModelFactory
import java.io.File
import java.util.Calendar

class ExportFragment : Fragment() {
    private var _binding: FragmentExportBinding? = null
    private val binding get() = _binding!!
    private val viewModel: TaxicoViewModel by activityViewModels { TaxicoViewModelFactory(requireActivity().application) }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentExportBinding.inflate(i, c, false); return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Export tout
        binding.btnExportAll.setOnClickListener {
            viewModel.allCourses.value?.let { courses ->
                viewModel.exportCSV(courses) { csv -> saveAndShare(csv, "taxico_complet.csv") }
            }
        }

        // Export mois courant
        binding.btnExportMois.setOnClickListener {
            val now = Calendar.getInstance()
            viewModel.getCoursesByMonth(now.get(Calendar.MONTH)+1, now.get(Calendar.YEAR)) { courses ->
                viewModel.exportCSV(courses) { csv -> saveAndShare(csv, "taxico_${now.get(Calendar.YEAR)}_${now.get(Calendar.MONTH)+1}.csv") }
            }
        }

        // Export année courante
        binding.btnExportAnnee.setOnClickListener {
            val year = Calendar.getInstance().get(Calendar.YEAR)
            viewModel.getCoursesByYear(year) { courses ->
                viewModel.exportCSV(courses) { csv -> saveAndShare(csv, "taxico_$year.csv") }
            }
        }
    }

    private fun saveAndShare(content: String, filename: String) {
        try {
            val file = File(requireContext().getExternalFilesDir(null), filename)
            file.writeText(content)
            // Partager via Intent
            val uri = androidx.core.content.FileProvider.getUriForFile(
                requireContext(), "${requireContext().packageName}.provider", file
            )
            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(android.content.Intent.createChooser(intent, "Exporter $filename"))
        } catch (e: Exception) {
            Toast.makeText(context, "Erreur export: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
